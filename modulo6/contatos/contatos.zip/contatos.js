module.exports = [
    {
        id: 1,
        nome: 'João',
        telefones: ['8765-4321', '1232-3421'],
        email: 'joao@hotmail.com'
    },
    { id: 2,
        nome: 'José',
        telefones: ['5678-1234'],
        email: 'jose@outlook.com'
    },
    {
        id: 3,
        nome: 'Joana',
        telefones: ['5487-6211', '4511-6325', '4811-2632'],
        email: 'joaase@outlook.com'
    }
]