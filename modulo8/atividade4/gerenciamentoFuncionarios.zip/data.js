let funcionarios = [
    {id:1, nome: 'João Silva', cargo: 'Desenvolvedor', departamento: 'TI', salario: 5000},
    {id:2, nome: 'Carlos Costa', cargo: 'Assitente de TI', departamento: 'TI', salario: 2000},
    {id:3, nome: 'Ana Claudia Silva', cargo: 'Analista de sistemas', departamento: 'TI', salario: 2500},
    {id:4, nome: 'Francisco Costa', cargo: 'Gerente de TI', departamento: 'TI', salario: 7000}
]

module.exports = { funcionarios }