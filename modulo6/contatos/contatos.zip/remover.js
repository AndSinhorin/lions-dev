let contatos = require('./contatos.js')

function removerContatos(id, resposta){
    let index = contatos.findIndex(contato => contato.id === id)
    let remover = (resposta === 's')

    if (remover) {
        (index !== -1)
        contatos.splice(index, 1)
        console.log('Contato removida com sucesso!')
    } else {
        console.log('Remoção cancelada! ')
    }
}
module.exports = removerContatos