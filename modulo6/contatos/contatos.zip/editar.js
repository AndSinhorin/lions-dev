let contatos = require('./contatos.js')

function editarContatos(index, nome, telefone, email){

    let jaExisteEmail = contatos.find(cont => cont.email === email)

    index = contatos.findIndex(contato => contato.id === index)
    
    if (jaExisteEmail){
        console.log('Já exite um contato com esse email');
    }else if (index !== -1){
        contatos[index] = {id:(contatos[index].id),nome:nome,telefones:telefone,email:email}
    } 
}
module.exports = editarContatos